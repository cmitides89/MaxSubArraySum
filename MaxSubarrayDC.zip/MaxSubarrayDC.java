/*************************************************************************
 *
 *  Pace University
 *
 *  Course: CS 608 Algorithms and Computing Theory
 *  Author: PUT YOUR NAME HERE
 *  Collaborators: PUT YOUR COLLABORATORS HERE, IF NONE, PUT NONE
 *  References: PUT THE LINKS TO YOUR SOURCES HERE
 *
 *  Assignment: PUT THE ASSIGNMENT NUMBER HERE
 *  Problem: PUT THE MAIN PROBLEM NAME HERE
 *  Description: PUT A BRIEF DESCRIPTION HERE
 *
 *  Input:
 *  Output:
 *
 *  Visible data fields:
 *  COPY DECLARATION OF VISIBLE DATA FIELDS HERE
 *
 *  Visible methods:
 *  COPY SIGNATURE OF VISIBLE METHODS HERE
 *
 *
 *   Remarks
 *   -------
 *
 *   PUT ALL NON-CODING ANSWERS HERE
 *
 *
 *************************************************************************/
class MaxSubarrayDC{
    public static void main(String[] args){

        int[] myArray = {-2,1,-3,4,-1,2,1,-5,4};
        // int low = findMinValue(myArray);
        // int high = findMaxValue(myArray);
        int low = -5;
        int high = 4;
        maxSubArray(myArray, low, high);
        // System.out.println("low is "+low + " high is " +high);
    }
    public static int maxSubArray(int[] a, int low, int high ){
        int mid;
        int leftSum;
        int rightSum;
        int crossSum;
        int max;
        if(high == low){
            return a[low];
        }else{
            mid = ((low + high)/2);
            //recursive call
            leftSum = maxSubArray(a, low, mid);
            rightSum = maxSubArray(a, mid+1, high);
            crossSum = maxCrossingSubArray(a, low, mid, high);
            if(leftSum >= crossSum && leftSum >= rightSum){
                return max = leftSum;
            } else if(crossSum >= leftSum && crossSum >= rightSum){
                return max = crossSum;
            }else{
                return max = rightSum;
            }
        }
    }

    public static int maxCrossingSubArray(int[] a, int low, int mid, int high){
        int leftSum = (int) Integer.MIN_VALUE;
        int rightSum = (int) Integer.MIN_VALUE;
        int sum = 0;
        for(int i = mid; i > low; i--){
            sum = sum + a[i];
            if(sum > leftSum){
                leftSum = sum;
            }
        }
        sum = 0;
        for(int j = mid+1; j < high; j++){
            sum = sum + a[j];
            if(sum > rightSum){
                rightSum = sum;
            }
        }
        return leftSum + rightSum;
    }

    // public static int findMaxValue(int[] arry){
    //     int maxVal = arry[0];
    //     for(int i=0; i < arry.length; i++){
    //         if(arry[i] > maxVal){
    //             maxVal = arry[i];
    //         }
    //     }
    //     return maxVal;
    // }
    // public static int findMinValue(int[] arry){
    //     int minVal = arry[0];
    //     for(int i = 0; i < arry.length; i++){
    //         if(arry[i] < minVal){
    //             minVal = arry[i];
    //         }
    //     }
    //     return minVal;
    // }

}
